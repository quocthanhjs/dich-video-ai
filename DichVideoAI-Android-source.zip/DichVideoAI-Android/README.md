# Dịch Video AI — Android foundation

This repository contains an initial Android foundation for a live video-translation app.

## Included in this foundation build

- Android app shell and independent subtitle/translated-voice switches.
- Region and speaker preference selectors (UI only).
- User-consented Android MediaProjection flow.
- AudioPlaybackCapture configuration for internal playback audio; no microphone audio source is selected.
- Foreground media-projection service.
- GitHub Actions workflow to build a debug APK artifact.

## Not implemented yet

This is **not a completed live translator**. Speech recognition, translation, Vietnamese speech synthesis, speaker diarization, floating captions over Telegram/X, audio ducking/mixing, secure AI backend configuration, and real-device compatibility testing remain to be implemented. The switches and voice selectors are currently UI foundations only.

Android playback capture is subject to Android version, user consent, source-app capture policy, and audio usage. Telegram or X may disallow capture for particular playback paths. Android also requires the `RECORD_AUDIO` permission as a prerequisite for AudioPlaybackCapture; the AudioRecord instance is configured for playback capture, not microphone input.

## Build

Push to `main` or manually run the **Build Android APK** workflow in GitHub Actions. The debug APK is uploaded as an artifact named `DichVideoAI-debug`.
