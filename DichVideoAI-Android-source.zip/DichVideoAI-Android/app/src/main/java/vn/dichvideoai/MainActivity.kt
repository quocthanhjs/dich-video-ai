package vn.dichvideoai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 4102
    private val requestAudioPermission = 4103
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF101827.toInt()
        window.navigationBarColor = 0xFF101827.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 44, 36, 32)
            setBackgroundColor(0xFF101827.toInt())
        }

        fun text(value: String, size: Float = 16f): TextView =
            TextView(this).apply {
                this.text = value
                textSize = size
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(0, 12, 0, 12)
            }

        root.addView(text("DỊCH VIDEO AI", 25f))
        root.addView(text("Bản nền kỹ thuật • Android 10 trở lên"))

        val subtitles = Switch(this).apply {
            text = "Hiển thị phụ đề tiếng Việt"
            isChecked = true
            setTextColor(0xFFFFFFFF.toInt())
        }
        val translatedVoice = Switch(this).apply {
            text = "Phát giọng dịch tiếng Việt"
            isChecked = true
            setTextColor(0xFFFFFFFF.toInt())
        }
        val duckOriginal = Switch(this).apply {
            text = "Giảm tiếng gốc khi đọc bản dịch"
            isChecked = true
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(subtitles)
        root.addView(translatedVoice)
        root.addView(duckOriginal)

        root.addView(text("Giọng vùng miền"))
        val region = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Miền Bắc", "Miền Nam")
            )
        }
        root.addView(region)

        root.addView(text("Giới tính giọng dịch"))
        val speaker = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Tự nhận diện người nói", "Giọng nam", "Giọng nữ")
            )
        }
        root.addView(speaker)

        root.addView(Button(this).apply {
            text = "CẤP QUYỀN THU ÂM THANH VIDEO"
            setOnClickListener { ensureAudioPermissionThenCapture() }
        })
        root.addView(Button(this).apply {
            text = "DỪNG THU ÂM THANH"
            setOnClickListener {
                stopService(Intent(this@MainActivity, PlaybackCaptureService::class.java))
                status.text = "Đã dừng phiên thu âm thanh nội bộ."
            }
        })

        status = text(
            "Chưa kết nối âm thanh. Đây là bản nền thử nghiệm; chức năng AI dịch và đọc tiếng Việt chưa được tích hợp."
        )
        root.addView(status)
        root.addView(text(
            "Android yêu cầu quyền RECORD_AUDIO để khởi tạo AudioPlaybackCapture. Dữ liệu được lấy từ âm thanh phát lại nội bộ, không chọn micro làm nguồn. Telegram/X vẫn có thể chặn chia sẻ âm thanh.",
            13f
        ))
        setContentView(root)
    }

    private fun ensureAudioPermissionThenCapture() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudioPermission)
        } else {
            requestPlaybackCapture()
        }
    }

    private fun requestPlaybackCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudioPermission) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                requestPlaybackCapture()
            } else {
                status.text = "Chưa cấp quyền cần thiết cho AudioPlaybackCapture."
            }
        }
    }

    @Deprecated("Deprecated by Android but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, PlaybackCaptureService::class.java).apply {
                    putExtra(PlaybackCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(PlaybackCaptureService.EXTRA_RESULT_DATA, data)
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent)
                else startService(serviceIntent)
                status.text = "Đã cấp quyền MediaProjection. Đang thử nhận âm thanh phát lại; chưa có dịch AI trong bản nền này."
            } else {
                status.text = "Bạn chưa cấp quyền thu âm thanh phát lại."
            }
        }
    }
}
